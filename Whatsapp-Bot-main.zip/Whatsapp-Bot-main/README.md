
#### WHATSAPP BOT USING BAILEYS

### Change in setting.js
 ```javascript
const website = {
    web: 'https://beforelife.me',
    apikey: 'xxxx' // ambil apikey nya di website https://beforelife.me
}
```

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

1. #### INSTALL IN TERMUX
 
```
apt update && apt upgrade -y
```
```
pkg install nodejs
```
```
pkg install git
```
```
git clone https://github.com/Rzky7c/Whatsapp-Bot
cd Whatsapp-Bot
```
```
npm install && npm start
```
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

2. #### INSTALL IN WINDOWS
 
* install git [`CLICK`](https://git-scm.com/downloads)

* install nodejs [`CLICK`](https://nodejs.org/en/download)

* install ffmpeg [`CLICK`](https://ffmpeg.org/download.html)

* install imagemagick [`CLICK`](https://imagemagick.org/script/download.php)

```
git clone https://github.com/Rzky7c/Whatsapp-Bot
```
```
cd Whatsapp-Bot
```
```
npm install && npm start
```
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<h2 align="center">  Information
</h2>
   
## 

- Dont selling this source code, this all free.
- If a plugin's code is obfuscated, you do not have permission to edit, modify, or alter it in any form.
- Remember: Always give proper credits if you're using or reuploading my plugins/files.


  
<p align="center">
Beforelife For Everyone
